#include "network.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static bool network_initialized = false;

bool network_init(void) {
    if (network_initialized) return true;
    
    Result ret;
    
    // Initialize AC (wireless) service
    ret = acInit();
    if (R_FAILED(ret)) {
        printf("Failed to initialize AC service: 0x%08lX\n", ret);
        return false;
    }
    
    // Wait for internet connection
    bool connected = false;
    for (int i = 0; i < 10; i++) {
        u32 wifi_status = 0;
        ret = ACU_GetWifiStatus(&wifi_status);
        if (R_SUCCEEDED(ret) && wifi_status) {
            connected = true;
            break;
        }
        svcSleepThread(1000000000LL); // Sleep for 1 second
    }
    
    if (!connected) {
        printf("No WiFi connection detected!\n");
        printf("Please ensure WiFi is enabled and connected.\n");
        acExit();
        return false;
    }
    
    printf("WiFi connected successfully!\n");
    network_initialized = true;
    return true;
}

void network_cleanup(void) {
    if (!network_initialized) return;
    
    acExit();
    network_initialized = false;
}

bool download_tile(int tile_x, int tile_y, int zoom, u8** buffer, u32* size) {
    if (!network_initialized) {
        return false;
    }
    
    char url[512];
    Result ret;
    httpcContext context;
    u32 statuscode = 0;
    u32 contentsize = 0, readsize = 0, downloaded_size = 0;
    u8 *buf = NULL, *lastbuf = NULL;
    
    // Build URL for OpenStreetMap tiles (free alternative to Google Maps)
    build_osm_url(tile_x, tile_y, zoom, url, sizeof(url));
    
    printf("Downloading tile: %d/%d/%d\n", zoom, tile_x, tile_y);
    
    // Initialize HTTP context
    ret = httpcOpenContext(&context, HTTPC_METHOD_GET, url, 1);
    if (R_FAILED(ret)) {
        printf("Failed to open HTTP context: 0x%08lX\n", ret);
        return false;
    }
    
    // Set headers for HTTP request
    ret = httpcAddRequestHeaderField(&context, "User-Agent", 
                                   "3DS-Google-Maps/1.0 (Nintendo 3DS)");
    if (R_FAILED(ret)) {
        printf("Failed to set User-Agent: 0x%08lX\n", ret);
        httpcCloseContext(&context);
        return false;
    }
    
    // Begin the request
    ret = httpcBeginRequest(&context);
    if (R_FAILED(ret)) {
        printf("Failed to begin HTTP request: 0x%08lX\n", ret);
        httpcCloseContext(&context);
        return false;
    }
    
    // Get response status
    ret = httpcGetResponseStatusCode(&context, &statuscode);
    if (R_FAILED(ret)) {
        printf("Failed to get response status: 0x%08lX\n", ret);
        httpcCloseContext(&context);
        return false;
    }
    
    if (statuscode != 200) {
        printf("HTTP request failed with status: %lu\n", statuscode);
        httpcCloseContext(&context);
        return false;
    }
    
    // Get content length (may be 0 if not provided)
    ret = httpcGetDownloadSizeState(&context, NULL, &contentsize);
    if (R_FAILED(ret)) {
        printf("Failed to get content length: 0x%08lX\n", ret);
        httpcCloseContext(&context);
        return false;
    }
    
    printf("Expected content size: %lu bytes\n", contentsize);
    
    // Start with a single page buffer
    buf = (u8*)malloc(0x1000);
    if (!buf) {
        printf("Failed to allocate initial buffer\n");
        httpcCloseContext(&context);
        return false;
    }
    
    // Download data in chunks, resizing buffer as needed
    do {
        ret = httpcDownloadData(&context, buf + downloaded_size, 0x1000, &readsize);
        downloaded_size += readsize;
        
        if (ret == (s32)HTTPC_RESULTCODE_DOWNLOADPENDING) {
            lastbuf = buf;
            buf = (u8*)realloc(buf, downloaded_size + 0x1000);
            if (!buf) {
                printf("Failed to reallocate buffer\n");
                free(lastbuf);
                httpcCloseContext(&context);
                return false;
            }
        }
    } while (ret == (s32)HTTPC_RESULTCODE_DOWNLOADPENDING);
    
    if (R_FAILED(ret)) {
        printf("Failed to download tile data: 0x%08lX\n", ret);
        free(buf);
        httpcCloseContext(&context);
        return false;
    }
    
    // Resize buffer to final size
    if (downloaded_size > 0) {
        lastbuf = buf;
        buf = (u8*)realloc(buf, downloaded_size);
        if (!buf) {
            buf = lastbuf; // Keep the original buffer if realloc fails
        }
    }
    
    *buffer = buf;
    *size = downloaded_size;
    httpcCloseContext(&context);
    
    printf("Successfully downloaded tile (%lu bytes)\n", downloaded_size);
    return true;
}

bool is_connected(void) {
    if (!network_initialized) return false;
    
    u32 wifi_status = 0;
    Result ret = ACU_GetWifiStatus(&wifi_status);
    return R_SUCCEEDED(ret) && wifi_status;
}

void build_osm_url(int tile_x, int tile_y, int zoom, char* url, size_t url_size) {
    // Using OpenStreetMap HTTP server (more compatible with 3DS)
    snprintf(url, url_size, 
             "http://a.tile.openstreetmap.org/%d/%d/%d.png",
             zoom, tile_x, tile_y);
}

void build_google_url(int tile_x, int tile_y, int zoom, char* url, size_t url_size) {
    // Google Maps tile server URL format (requires API key for production use)
    // Note: This is just an example format - actual Google Maps API requires authentication
    snprintf(url, url_size, 
             "https://mt1.google.com/vt/lyrs=m&x=%d&y=%d&z=%d",
             tile_x, tile_y, zoom);
}
